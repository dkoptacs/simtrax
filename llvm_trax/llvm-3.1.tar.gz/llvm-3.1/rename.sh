for f in MBlaze*; 
do 
    mv "$f" "Trax${f#MBlaze}"; 
done